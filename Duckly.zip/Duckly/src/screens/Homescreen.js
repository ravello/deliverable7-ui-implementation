import React, { Component } from "react";
import styled, { css } from "styled-components";
import MaterialSearchBar from "../components/MaterialSearchBar";
import MaterialCard121 from "../components/MaterialCard121";
import MaterialCard123 from "../components/MaterialCard123";
import MaterialCard12 from "../components/MaterialCard12";
import { Link } from "react-router-dom";
import CupertinoSegmentWithTwoTabs from "../components/CupertinoSegmentWithTwoTabs";
import CupertinoButtonInfo from "../components/CupertinoButtonInfo";

function Homescreen(props) {
  return (
    <Container>
      <ButtonRow>
        <Button>
          <ButtonOverlay>
            <MaterialSearchBar
              style={{
                height: 55,
                width: 348,
                marginTop: 16,
                marginLeft: 9
              }}
            ></MaterialSearchBar>
            <MaterialCard121
              style={{
                height: 92,
                width: 350,
                marginLeft: 9
              }}
            ></MaterialCard121>
            <MaterialCard123
              titleStyle="Title goes here"
              style={{
                height: 89,
                width: 350,
                marginTop: 8,
                marginLeft: 9
              }}
              titleStyle="Robert Bob"
              subtitleStyle="Junior Software Developer"
            ></MaterialCard123>
          </ButtonOverlay>
        </Button>
        <OnGoingSessionsStack>
          <OnGoingSessions>On Going Sessions</OnGoingSessions>
          <Rect>
            <MaterialCard12Stack>
              <MaterialCard12
                style={{
                  position: "absolute",
                  left: 0,
                  top: 0,
                  width: 359,
                  height: 206
                }}
              ></MaterialCard12>
              <Link to="/Collabscreen">
                <Button3>
                  <ButtonOverlay></ButtonOverlay>
                </Button3>
              </Link>
            </MaterialCard12Stack>
          </Rect>
        </OnGoingSessionsStack>
      </ButtonRow>
      <ImageStackRow>
        <ImageStack>
          <Image src={require("../assets/images/zach.jpeg")}></Image>
          <CupertinoSegmentWithTwoTabs
            titleRight="Cubs"
            style={{
              height: 54,
              width: 362,
              position: "absolute",
              left: 0,
              top: 222,
              overflow: "visible"
            }}
            titleLeft="Friends List"
            titleRight="Voice Chat"
          ></CupertinoSegmentWithTwoTabs>
        </ImageStack>
        <CupertinoButtonInfo
          style={{
            width: 100,
            height: 44,
            marginLeft: 798,
            marginTop: 20
          }}
        ></CupertinoButtonInfo>
      </ImageStackRow>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  background-color: rgba(255,255,255,1);
  flex-direction: column;
  height: 100vh;
  width: 100vw;
`;

const ButtonOverlay = styled.button`
 display: block;
 background: none;
 height: 100%;
 width: 100%;
 border:none
 `;
const Button = styled.div`
  width: 362px;
  height: 519px;
  background-color: #E6E6E6;
  flex-direction: column;
  display: flex;
  border: none;
`;

const OnGoingSessions = styled.span`
  font-family: Roboto;
  top: 16px;
  left: 303px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 34px;
`;

const Rect = styled.div`
  left: 0px;
  width: 891px;
  height: 510px;
  position: absolute;
  background-color: rgba(230,230, 230,0.27);
  top: 0px;
  flex-direction: column;
  display: flex;
`;

const Button3 = styled.div`
  top: 0px;
  left: 0px;
  width: 359px;
  height: 206px;
  position: absolute;
  background-color: #E6E6E6;
  opacity: 0;
  border: none;
`;

const MaterialCard12Stack = styled.div`
  width: 359px;
  height: 206px;
  margin-top: 71px;
  margin-left: 67px;
  position: relative;
`;

const OnGoingSessionsStack = styled.div`
  width: 891px;
  height: 510px;
  margin-left: 9px;
  position: relative;
`;

const ButtonRow = styled.div`
  height: 519px;
  flex-direction: row;
  display: flex;
  margin-top: 281px;
  margin-right: 18px;
`;

const Image = styled.img`
  top: 0px;
  left: 62px;
  width: 234px;
  height: 229px;
  position: absolute;
  object-fit: contain;
`;

const ImageStack = styled.div`
  width: 362px;
  height: 276px;
  position: relative;
`;

const ImageStackRow = styled.div`
  height: 276px;
  flex-direction: row;
  display: flex;
  margin-top: -807px;
  margin-left: 2px;
  margin-right: 18px;
`;

export default Homescreen;
