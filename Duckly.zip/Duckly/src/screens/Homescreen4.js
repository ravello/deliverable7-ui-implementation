import React, { Component } from "react";
import styled, { css } from "styled-components";
import CupertinoButtonInfo2 from "../components/CupertinoButtonInfo2";
import { Link } from "react-router-dom";
import MaterialCard12 from "../components/MaterialCard12";
import CupertinoButtonInfo from "../components/CupertinoButtonInfo";
import CupertinoSegmentWithTwoTabs1 from "../components/CupertinoSegmentWithTwoTabs1";

function Homescreen4(props) {
  return (
    <Container>
      <Rect2Row>
        <Rect2>
          <VoiceChat1Row>
            <VoiceChat1>Voice Chat 1</VoiceChat1>
            <JoinStack>
              <Join>Join</Join>
              <Rect4></Rect4>
            </JoinStack>
          </VoiceChat1Row>
          <VoiceChat2Row>
            <VoiceChat2>Voice Chat 2</VoiceChat2>
            <Join1Stack>
              <Join1>Join</Join1>
              <Rect5></Rect5>
            </Join1Stack>
          </VoiceChat2Row>
          <Rect3>
            <WelcomeStack>
              <Welcome>
                You joined voice chat 2{"\n"}Say &quot;Hi!&quot;
              </Welcome>
              <CupertinoButtonInfo2
                style={{
                  height: 20,
                  width: 64,
                  position: "absolute",
                  left: 85,
                  top: 89,
                  borderWidth: 1,
                  borderColor: "#000000",
                  borderStyle: "solid"
                }}
              ></CupertinoButtonInfo2>
              <Link to="/Homescreen2">
                <Button6>
                  <ButtonOverlay></ButtonOverlay>
                </Button6>
              </Link>
            </WelcomeStack>
          </Rect3>
        </Rect2>
        <OnGoingSessionsStack>
          <OnGoingSessions>On Going Sessions</OnGoingSessions>
          <Rect>
            <MaterialCard12Stack>
              <MaterialCard12
                style={{
                  position: "absolute",
                  left: 0,
                  top: 0,
                  width: 359,
                  height: 206
                }}
              ></MaterialCard12>
              <Link to="/Collabscreen">
                <Button3>
                  <ButtonOverlay></ButtonOverlay>
                </Button3>
              </Link>
            </MaterialCard12Stack>
          </Rect>
        </OnGoingSessionsStack>
      </Rect2Row>
      <ImageRow>
        <Image src={require("../assets/images/zach.jpeg")}></Image>
        <CupertinoButtonInfo
          style={{
            width: 100,
            height: 44,
            marginLeft: 864,
            marginTop: 20
          }}
        ></CupertinoButtonInfo>
      </ImageRow>
      <CupertinoSegmentWithTwoTabs1
        titleLeft="Puppies"
        titleRight="Cubs"
        style={{
          height: 56,
          width: 371,
          marginTop: 3
        }}
        friendsList="Friends List"
        voiceChat="Voice Chat"
      ></CupertinoSegmentWithTwoTabs1>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  background-color: rgba(255,255,255,1);
  flex-direction: column;
  height: 100vh;
  width: 100vw;
`;

const ButtonOverlay = styled.button`
 display: block;
 background: none;
 height: 100%;
 width: 100%;
 border:none
 `;
const Rect2 = styled.div`
  width: 362px;
  height: 519px;
  background-color: #E6E6E6;
  flex-direction: column;
  display: flex;
`;

const VoiceChat1 = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: #121212;
`;

const Join = styled.span`
  font-family: Roboto;
  top: 0px;
  left: 0px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: rgba(74,144,226,1);
  text-decoration-line: underline;
`;

const Rect4 = styled.div`
  top: 0px;
  left: 0px;
  width: 27px;
  height: 17px;
  position: absolute;
  background-color: #E6E6E6;
  opacity: 0;
`;

const JoinStack = styled.div`
  width: 27px;
  height: 17px;
  margin-left: 136px;
  position: relative;
`;

const VoiceChat1Row = styled.div`
  height: 17px;
  flex-direction: row;
  display: flex;
  margin-top: 19px;
  margin-left: 24px;
  margin-right: 96px;
`;

const VoiceChat2 = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: #121212;
`;

const Join1 = styled.span`
  font-family: Roboto;
  top: 0px;
  left: 0px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: rgba(74,144,226,1);
  text-decoration-line: underline;
`;

const Rect5 = styled.div`
  top: 0px;
  left: 0px;
  width: 27px;
  height: 17px;
  position: absolute;
  background-color: #E6E6E6;
  opacity: 0;
`;

const Join1Stack = styled.div`
  width: 27px;
  height: 17px;
  margin-left: 136px;
  position: relative;
`;

const VoiceChat2Row = styled.div`
  height: 17px;
  flex-direction: row;
  display: flex;
  margin-top: 21px;
  margin-left: 24px;
  margin-right: 96px;
`;

const Rect3 = styled.div`
  width: 155px;
  height: 120px;
  background-color: #E6E6E6;
  border-width: 1px;
  border-color: #000000;
  flex-direction: column;
  display: flex;
  margin-top: 8px;
  margin-left: 201px;
  border-style: solid;
`;

const Welcome = styled.span`
  font-family: Roboto;
  top: 0px;
  left: 0px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  height: 109px;
  width: 144px;
`;

const Button6 = styled.div`
  top: 89px;
  left: 85px;
  width: 64px;
  height: 20px;
  position: absolute;
  background-color: #E6E6E6;
  opacity: 0;
  border: none;
`;

const WelcomeStack = styled.div`
  width: 149px;
  height: 109px;
  margin-top: 11px;
  margin-left: 6px;
  position: relative;
`;

const OnGoingSessions = styled.span`
  font-family: Roboto;
  top: 16px;
  left: 303px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 34px;
`;

const Rect = styled.div`
  left: 0px;
  width: 891px;
  height: 510px;
  position: absolute;
  background-color: rgba(230,230, 230,0.27);
  top: 0px;
  flex-direction: column;
  display: flex;
`;

const Button3 = styled.div`
  top: 0px;
  left: 0px;
  width: 359px;
  height: 206px;
  position: absolute;
  background-color: #E6E6E6;
  opacity: 0;
  border: none;
`;

const MaterialCard12Stack = styled.div`
  width: 359px;
  height: 206px;
  margin-top: 71px;
  margin-left: 67px;
  position: relative;
`;

const OnGoingSessionsStack = styled.div`
  width: 891px;
  height: 510px;
  margin-left: 9px;
  position: relative;
`;

const Rect2Row = styled.div`
  height: 519px;
  flex-direction: row;
  display: flex;
  margin-top: 281px;
  margin-right: 18px;
`;

const Image = styled.img`
  width: 100%;
  height: 229px;
  object-fit: contain;
`;

const ImageRow = styled.div`
  height: 229px;
  flex-direction: row;
  display: flex;
  margin-top: -807px;
  margin-left: 64px;
  margin-right: 18px;
`;

export default Homescreen4;
