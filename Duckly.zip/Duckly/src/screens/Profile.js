import React, { Component } from "react";
import styled, { css } from "styled-components";
import { Link } from "react-router-dom";
import MaterialFixedLabelTextbox3 from "../components/MaterialFixedLabelTextbox3";
import MaterialFixedLabelTextbox2 from "../components/MaterialFixedLabelTextbox2";
import MaterialFixedLabelTextbox1 from "../components/MaterialFixedLabelTextbox1";

function Profile(props) {
  return (
    <Container>
      <Image1>
        <Link to="/Homescreen1">
          <Button>
            <ButtonOverlay>
              <TextInput placeholder="Back"></TextInput>
            </ButtonOverlay>
          </Button>
        </Link>
      </Image1>
      <MaterialFixedLabelTextbox1Stack>
        <MaterialFixedLabelTextbox3
          label="FixedLabel"
          style={{
            height: 43,
            width: 375,
            position: "absolute",
            top: 17,
            left: 0
          }}
        ></MaterialFixedLabelTextbox3>
        <Role>Role</Role>
      </MaterialFixedLabelTextbox1Stack>
      <MaterialFixedLabelTextbox2Stack>
        <MaterialFixedLabelTextbox2
          label="FixedLabel"
          style={{
            height: 43,
            width: 375,
            position: "absolute",
            left: 0,
            top: 17
          }}
        ></MaterialFixedLabelTextbox2>
        <Name>Name</Name>
      </MaterialFixedLabelTextbox2Stack>
      <MaterialFixedLabelTextbox1
        label="FixedLabel"
        style={{
          height: 43,
          width: 375,
          marginTop: 52,
          marginLeft: 452
        }}
      ></MaterialFixedLabelTextbox1>
      <Link to="/Homescreen1">
        <Button2>
          <ButtonOverlay>
            <TextInput2 placeholder="Save"></TextInput2>
          </ButtonOverlay>
        </Button2>
      </Link>
      <Email>Email</Email>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  background-color: #7e7c7c;
  flex-direction: column;
  height: 100vh;
  width: 100vw;
`;

const ButtonOverlay = styled.button`
 display: block;
 background: none;
 height: 100%;
 width: 100%;
 border:none
 `;
const Image1 = styled.div`
  height: 100%;
  flex-direction: column;
  display: flex;
  margin-top: 49px;
  background-image: url(${require("../assets/images/zach.jpeg")});
  background-size: cover;
`;

const Button = styled.div`
  width: 100px;
  height: 36px;
  background-color: rgba(4,4,4,1);
  border-radius: 5px;
  shadow-radius: 0px;
  flex-direction: column;
  display: flex;
  margin-left: 63px;
  border: none;
  box-shadow: 3px 3px 0px  0.18px rgba(0,0,0,1) ;
`;

const TextInput = styled.input`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  width: 35px;
  height: 17px;
  margin-top: 9px;
  margin-left: 32px;
  border: none;
  background: transparent;
`;

const Role = styled.span`
  font-family: Roboto;
  top: 0px;
  left: 2px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  width: 35px;
  height: 33px;
`;

const MaterialFixedLabelTextbox1Stack = styled.div`
  width: 375px;
  height: 60px;
  margin-top: 219px;
  margin-left: 452px;
  position: relative;
`;

const Name = styled.span`
  font-family: Roboto;
  top: 0px;
  left: 2px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  width: 45px;
  height: 33px;
`;

const MaterialFixedLabelTextbox2Stack = styled.div`
  width: 375px;
  height: 60px;
  margin-top: -248px;
  margin-left: 452px;
  position: relative;
`;

const Button2 = styled.div`
  width: 100px;
  height: 36px;
  background-color: rgba(4,4,4,1);
  border-radius: 5px;
  shadow-radius: 0px;
  flex-direction: column;
  display: flex;
  margin-top: 205px;
  margin-left: 590px;
  border: none;
  box-shadow: 3px 3px 0px  0.18px rgba(0,0,0,1) ;
`;

const TextInput2 = styled.input`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  width: 33px;
  height: 17px;
  margin-top: 10px;
  margin-left: 33px;
  border: none;
  background: transparent;
`;

const Email = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  width: 35px;
  height: 17px;
  margin-top: -301px;
  margin-left: 454px;
`;

export default Profile;
