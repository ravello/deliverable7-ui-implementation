import React, { Component } from "react";
import styled, { css } from "styled-components";
import MaterialStackedLabelTextbox from "../components/MaterialStackedLabelTextbox";
import { Link } from "react-router-dom";

function Login(props) {
  return (
    <Container>
      <MaterialStackedLabelTextbox
        style={{
          height: 60,
          width: 375,
          marginTop: 360,
          marginLeft: 452
        }}
      ></MaterialStackedLabelTextbox>
      <MaterialStackedLabelTextbox1Stack>
        <MaterialStackedLabelTextbox
          style={{
            height: 60,
            width: 375,
            position: "absolute",
            left: 0,
            top: 24
          }}
        ></MaterialStackedLabelTextbox>
        <Password>password</Password>
      </MaterialStackedLabelTextbox1Stack>
      <Image src={require("../assets/images/duckly_logo1.jpeg")}></Image>
      <TextInput placeholder="email"></TextInput>
      <Button2Row>
        <Link to="/Homescreen1">
          <Button2>
            <ButtonOverlay>
              <Text2>Login</Text2>
            </ButtonOverlay>
          </Button2>
        </Link>
        <Link to="/Signup">
          <Button>
            <ButtonOverlay>
              <Signup>Signup</Signup>
            </ButtonOverlay>
          </Button>
        </Link>
      </Button2Row>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  background-color: rgba(127,124,124,1);
  flex-direction: column;
  height: 100vh;
  width: 100vw;
`;

const ButtonOverlay = styled.button`
 display: block;
 background: none;
 height: 100%;
 width: 100%;
 border:none
 `;
const Password = styled.span`
  font-family: Roboto;
  top: 0px;
  left: 0px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 20px;
  width: 97px;
  height: 47px;
`;

const MaterialStackedLabelTextbox1Stack = styled.div`
  width: 375px;
  height: 84px;
  margin-top: 20px;
  margin-left: 452px;
  position: relative;
`;

const Image = styled.img`
  width: 200px;
  height: 100%;
  margin-top: -461px;
  margin-left: 540px;
  object-fit: contain;
`;

const TextInput = styled.input`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: rgba(0,0,0,1);
  width: 194px;
  height: 36px;
  font-size: 20px;
  margin-top: 61px;
  margin-left: 452px;
  border: none;
  background: transparent;
`;

const Button2 = styled.div`
  width: 100px;
  height: 36px;
  background-color: rgba(0,0,0,1);
  border-radius: 5px;
  shadow-radius: 0px;
  flex-direction: column;
  display: flex;
  border: none;
  box-shadow: 3px 3px 0px  0.18px rgba(0,0,0,1) ;
`;

const Text2 = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: rgba(251,248,248,1);
  width: 35px;
  height: 17px;
  margin-top: 10px;
  margin-left: 32px;
`;

const Button = styled.div`
  width: 100px;
  height: 36px;
  background-color: rgba(10,10,10,1);
  shadow-radius: 0px;
  border-radius: 5px;
  flex-direction: column;
  display: flex;
  margin-left: 93px;
  border: none;
  box-shadow: 3px 3px 0px  0.18px rgba(0,0,0,1) ;
`;

const Signup = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: rgba(255,255,255,1);
  width: 43px;
  height: 17px;
  margin-top: 10px;
  margin-left: 28px;
`;

const Button2Row = styled.div`
  height: 36px;
  flex-direction: row;
  display: flex;
  margin-top: 282px;
  margin-left: 497px;
  margin-right: 490px;
`;

export default Login;
