import React, { Component } from "react";
import styled, { css } from "styled-components";
import CupertinoSegmentWithTwoTabs from "../components/CupertinoSegmentWithTwoTabs";
import MaterialSearchBar from "../components/MaterialSearchBar";
import MaterialCard121 from "../components/MaterialCard121";
import MaterialCard123 from "../components/MaterialCard123";
import MaterialChipBasic from "../components/MaterialChipBasic";
import MaterialFixedLabelTextbox5 from "../components/MaterialFixedLabelTextbox5";
import CupertinoButtonInfo1 from "../components/CupertinoButtonInfo1";

function Collabscreen(props) {
  return (
    <Container>
      <RectStackRow>
        <RectStack>
          <Rect>
            <CupertinoSegmentWithTwoTabs
              titleRight="Cubs"
              style={{
                height: 54,
                width: 362,
                borderWidth: 1,
                borderColor: "#000000",
                overflow: "visible",
                borderStyle: "solid"
              }}
              titleLeft="Friends List"
              titleRight="Voice Chat"
            ></CupertinoSegmentWithTwoTabs>
            <MaterialSearchBar
              style={{
                height: 55,
                width: 348,
                marginTop: 16,
                marginLeft: 8
              }}
            ></MaterialSearchBar>
            <MaterialCard121
              style={{
                height: 92,
                width: 350,
                marginLeft: 8
              }}
            ></MaterialCard121>
            <MaterialCard123
              titleStyle="Title goes here"
              style={{
                height: 89,
                width: 350,
                marginTop: 9,
                marginLeft: 8
              }}
              titleStyle="Robert Bob"
              subtitleStyle="Junior Software Developer"
            ></MaterialCard123>
          </Rect>
          <Rect2>
            <MaterialChipBasic
              style={{
                width: 150,
                height: 32,
                marginTop: 12,
                marginLeft: 33
              }}
            ></MaterialChipBasic>
            <LoremIpsum5>
              - File 1{"\n"}
              {"\n"}- File 2{"\n"}
              {"\n"}- File 3
            </LoremIpsum5>
          </Rect2>
        </RectStack>
        <MaterialFixedLabelTextbox5
          style={{
            height: 689,
            width: 867,
            backgroundColor: "rgba(235,239,241,1)",
            marginLeft: 23
          }}
        ></MaterialFixedLabelTextbox5>
      </RectStackRow>
      <CupertinoButtonInfo1StackRow>
        <CupertinoButtonInfo1Stack>
          <CupertinoButtonInfo1
            style={{
              height: 44,
              width: 100,
              position: "absolute",
              left: 0,
              top: 0
            }}
          ></CupertinoButtonInfo1>
          <Button2>
            <ButtonOverlay
              onClick={() => props.history.goBack()}
            ></ButtonOverlay>
          </Button2>
        </CupertinoButtonInfo1Stack>
        <File1>File 1</File1>
      </CupertinoButtonInfo1StackRow>
      <LoremIpsum>Lorem Ipsum</LoremIpsum>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  background-color: rgba(255,255,255,1);
  flex-direction: column;
  height: 100vh;
  width: 100vw;
`;

const ButtonOverlay = styled.button`
 display: block;
 background: none;
 height: 100%;
 width: 100%;
 border:none
 `;
const Rect = styled.div`
  left: 0px;
  width: 362px;
  height: 934px;
  position: absolute;
  background-color: rgba(230,230, 230,0.27);
  top: 0px;
  flex-direction: column;
  display: flex;
`;

const Rect2 = styled.div`
  top: 375px;
  left: 0px;
  width: 362px;
  height: 629px;
  position: absolute;
  background-color: rgba(216,212,212,1);
  flex-direction: column;
  display: flex;
`;

const LoremIpsum5 = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 24px;
  width: 185px;
  height: 140px;
  margin-top: 25px;
  margin-left: 33px;
`;

const RectStack = styled.div`
  width: 362px;
  height: 1004px;
  position: relative;
`;

const RectStackRow = styled.div`
  height: 1004px;
  flex-direction: row;
  display: flex;
  margin-top: 76px;
  margin-right: 28px;
`;

const Button2 = styled.div`
  top: 0px;
  left: 0px;
  width: 100px;
  height: 44px;
  position: absolute;
  background-color: #E6E6E6;
  opacity: 0;
  border: none;
`;

const CupertinoButtonInfo1Stack = styled.div`
  width: 100px;
  height: 44px;
  position: relative;
`;

const File1 = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 700;
  color: #121212;
  font-size: 24px;
  width: 59px;
  height: 28px;
  margin-left: 262px;
  margin-top: 22px;
`;

const CupertinoButtonInfo1StackRow = styled.div`
  height: 50px;
  flex-direction: row;
  display: flex;
  margin-top: -1064px;
  margin-left: 23px;
  margin-right: 836px;
`;

const LoremIpsum = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  margin-top: -4488px;
  margin-left: -6837px;
`;

export default Collabscreen;
