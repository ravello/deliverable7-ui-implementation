import React, { Component } from "react";
import styled, { css } from "styled-components";
import CupertinoSegmentWithTwoTabs from "../components/CupertinoSegmentWithTwoTabs";

function Untitled3(props) {
  return (
    <Container>
      <RectRow>
        <Rect>
          <Image src={require("../assets/images/zach.jpeg")}></Image>
          <CupertinoSegmentWithTwoTabs
            titleRight="Cubs"
            style={{
              height: 59,
              width: 362,
              borderWidth: 1,
              borderColor: "#000000",
              overflow: "visible",
              borderStyle: "solid"
            }}
            titleLeft="Friends List"
            titleRight="Voice Chat"
            segmentTextWrapperLeft="Untitled1"
          ></CupertinoSegmentWithTwoTabs>
          <Rect2></Rect2>
        </Rect>
        <Button>
          <ButtonOverlay>
            <Project>+ project</Project>
          </ButtonOverlay>
        </Button>
      </RectRow>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  background-color: rgba(255,255,255,1);
  flex-direction: row;
  height: 100vh;
  width: 100vw;
`;

const ButtonOverlay = styled.button`
 display: block;
 background: none;
 height: 100%;
 width: 100%;
 border:none
 `;
const Rect = styled.div`
  width: 362px;
  height: 1080px;
  background-color: #E6E6E6;
  flex-direction: column;
  display: flex;
`;

const Image = styled.img`
  width: 234px;
  height: 100%;
  margin-left: 64px;
  object-fit: contain;
`;

const Rect2 = styled.div`
  width: 362px;
  height: 771px;
  background-color: rgba(216,212,212,1);
  margin-top: 21px;
`;

const Button = styled.div`
  width: 231px;
  height: 66px;
  background-color: #E6E6E6;
  flex-direction: column;
  display: flex;
  margin-left: 46px;
  margin-top: 49px;
  border: none;
`;

const Project = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 47px;
  margin-left: 22px;
`;

const RectRow = styled.div`
  height: 1080px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 641px;
`;

export default Untitled3;
