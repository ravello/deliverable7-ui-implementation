import React, { Component } from "react";
import styled, { css } from "styled-components";
import MaterialFixedLabelTextbox1 from "../components/MaterialFixedLabelTextbox1";
import MaterialFixedLabelTextbox2 from "../components/MaterialFixedLabelTextbox2";
import MaterialFixedLabelTextbox3 from "../components/MaterialFixedLabelTextbox3";
import MaterialFixedLabelTextbox4 from "../components/MaterialFixedLabelTextbox4";
import { Link } from "react-router-dom";

function Signup(props) {
  return (
    <Container>
      <Image1 src={require("../assets/images/duckly_logo1.jpeg")}></Image1>
      <MaterialFixedLabelTextbox1
        label="FixedLabel"
        style={{
          height: 43,
          width: 375,
          marginTop: 136,
          marginLeft: 452
        }}
      ></MaterialFixedLabelTextbox1>
      <MaterialFixedLabelTextbox2
        label="FixedLabel"
        style={{
          height: 43,
          width: 375,
          marginTop: -132,
          marginLeft: 452
        }}
      ></MaterialFixedLabelTextbox2>
      <MaterialFixedLabelTextbox3
        label="FixedLabel"
        style={{
          height: 43,
          width: 375,
          marginTop: 136,
          marginLeft: 452
        }}
      ></MaterialFixedLabelTextbox3>
      <MaterialFixedLabelTextbox4
        label="FixedLabel"
        style={{
          height: 43,
          width: 375,
          marginTop: 44,
          marginLeft: 452
        }}
      ></MaterialFixedLabelTextbox4>
      <Link to="/Homescreen1">
        <Button>
          <ButtonOverlay>
            <Text>Sign Up</Text>
          </ButtonOverlay>
        </Button>
      </Link>
      <TextInput placeholder="Emal"></TextInput>
      <TextInput2 placeholder="Password"></TextInput2>
      <TextInput3 placeholder="Name"></TextInput3>
      <TextInput4 placeholder="Team Link"></TextInput4>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  background-color: #7e7c7c;
  flex-direction: column;
  height: 100vh;
  width: 100vw;
`;

const ButtonOverlay = styled.button`
 display: block;
 background: none;
 height: 100%;
 width: 100%;
 border:none
 `;
const Image1 = styled.img`
  width: 200px;
  height: 100%;
  margin-top: 64px;
  margin-left: 540px;
  object-fit: contain;
`;

const Button = styled.div`
  width: 100px;
  height: 36px;
  background-color: rgba(4,4,4,1);
  border-radius: 5px;
  shadow-radius: 0px;
  flex-direction: column;
  display: flex;
  margin-top: 92px;
  margin-left: 590px;
  border: none;
  box-shadow: 3px 3px 0px  0.18px rgba(0,0,0,1) ;
`;

const Text = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: rgba(251,248,248,1);
  width: 48px;
  height: 17px;
  margin-top: 10px;
  margin-left: 26px;
`;

const TextInput = styled.input`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  width: 82px;
  height: 17px;
  margin-top: -454px;
  margin-left: 452px;
  border: none;
  background: transparent;
`;

const TextInput2 = styled.input`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  width: 82px;
  height: 17px;
  margin-top: 72px;
  margin-left: 452px;
  border: none;
  background: transparent;
`;

const TextInput3 = styled.input`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  width: 82px;
  height: 17px;
  margin-top: 73px;
  margin-left: 452px;
  border: none;
  background: transparent;
`;

const TextInput4 = styled.input`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  width: 82px;
  height: 17px;
  margin-top: 70px;
  margin-left: 452px;
  border: none;
  background: transparent;
`;

export default Signup;
