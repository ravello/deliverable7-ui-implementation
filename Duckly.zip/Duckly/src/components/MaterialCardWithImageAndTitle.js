import React, { Component } from "react";
import styled, { css } from "styled-components";

function MaterialCardWithImageAndTitle(props) {
  return (
    <Container {...props}>
      <Project2>Project 2</Project2>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  border-width: 1px;
  border-radius: 2px;
  border-color: #CCC;
  flex-wrap: nowrap;
  background-color: #FFF;
  overflow: hidden;
  flex-direction: column;
  border-style: solid;
  box-shadow: -2px 2px 1.5px  0.1px #000 ;
`;

const Project2 = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  margin-top: 148px;
  margin-left: 22px;
`;

export default MaterialCardWithImageAndTitle;
