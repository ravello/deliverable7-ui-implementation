import React, { Component } from "react";
import styled, { css } from "styled-components";

function MaterialCard12(props) {
  return (
    <Container {...props}>
      <CardBody>
        <BodyContent>
          <Project1></Project1>
        </BodyContent>
      </CardBody>
      <Project12>Project 1</Project12>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  border-width: 1px;
  border-radius: 2px;
  border-color: #CCC;
  flex-wrap: nowrap;
  background-color: #FFF;
  overflow: hidden;
  flex-direction: column;
  border-style: solid;
  position: relative;
  box-shadow: -2px 2px 1.5px  0.1px #000 ;
`;

const CardBody = styled.div`
  flex-direction: row;
  justify-content: space-between;
  display: flex;
`;

const BodyContent = styled.div`
  padding: 16px;
  padding-top: 24px;
  flex: 1 1 0%;
  flex-direction: column;
  display: flex;
`;

const Project1 = styled.span`
  font-family: Roboto;
  font-size: 21px;
  color: #000;
  padding-bottom: 12px;
`;

const Project12 = styled.span`
  font-family: Roboto;
  top: 173px;
  left: 24px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: #121212;
`;

export default MaterialCard12;
