import React, { Component } from "react";
import styled, { css } from "styled-components";

function MaterialChipBasic(props) {
  return (
    <Container {...props}>
      <Documents>DOCUMENTS</Documents>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: rgb(230,230,230);
  border-radius: 50px;
  padding-left: 12px;
  padding-right: 12px;
  flex-direction: column;
`;

const Documents = styled.span`
  font-family: Arial;
  font-size: 13px;
  color: rgba(0,0,0,0.87);
`;

export default MaterialChipBasic;
