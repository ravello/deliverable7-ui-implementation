import React, { Component } from "react";
import styled, { css } from "styled-components";

function CupertinoButtonInfo2(props) {
  return (
    <Container {...props}>
      <Close>Close</Close>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  background-color: #007AFF;
  justify-content: center;
  align-items: center;
  flex-direction: row;
  border-radius: 5px;
  padding-left: 16px;
  padding-right: 16px;
`;

const Close = styled.span`
  font-family: Roboto;
  color: #fff;
  font-size: 17px;
  font-weight: 500;
`;

export default CupertinoButtonInfo2;
