import React, { Component } from "react";
import styled, { css } from "styled-components";

function MaterialButtonDark1(props) {
  return (
    <Container {...props}>
      <TextInput placeholder={props.textInput || "Sign Up"}></TextInput>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  background-color: #212121;
  justify-content: center;
  align-items: center;
  flex-direction: row;
  border-radius: 2px;
  min-width: 88px;
  padding-left: 16px;
  padding-right: 16px;
  box-shadow: 0px 1px 5px  0.35px #000 ;
`;

const TextInput = styled.input`
  font-family: Roboto;
  color: rgba(255,255,255,1);
  font-size: 14px;
  width: 54px;
  height: 17px;
  border: none;
  background: transparent;
`;

export default MaterialButtonDark1;
