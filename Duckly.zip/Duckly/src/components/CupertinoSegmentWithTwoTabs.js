import React, { Component } from "react";
import styled, { css } from "styled-components";
import { Link } from "react-router-dom";

function CupertinoSegmentWithTwoTabs(props) {
  return (
    <Container {...props}>
      <Rect style={{ backgroundColor: props.textWrapper || undefined }}>
        <Link to="/Homescreen">
          <Button>
            <ButtonOverlay /* Conditional navigation not supported at the moment */
            >
              <TextInput placeholder="Friends List"></TextInput>
            </ButtonOverlay>
          </Button>
        </Link>
        <Link to="/Homescreen2">
          <SegmentTextWrapperRight>
            <ButtonOverlay>
              <TextInput2 placeholder="Voice Chat"></TextInput2>
            </ButtonOverlay>
          </SegmentTextWrapperRight>
        </Link>
      </Rect>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  background-color: #FFF;
  border-width: 0px;
  border-color: #000000;
  border-radius: 2px;
  border-style: solid;
`;

const ButtonOverlay = styled.button`
 display: block;
 background: none;
 height: 100%;
 width: 100%;
 border:none
 `;
const Rect = styled.div`
  height: 29px;
  flex: 1 1 0%;
  padding-left: 30px;
  padding-right: 30px;
  flex-direction: row;
  left: -13px;
  width: 184px;
  top: 14px;
  display: flex;
`;

const Button = styled.div`
  flex: 1 1 0%;
  align-items: center;
  background-color: #007AFF;
  padding: 6px;
  border-width: 1px;
  border-color: #007AFF;
  border-bottom-left-radius: 5px;
  border-top-left-radius: 5px;
  flex-direction: column;
  display: flex;
  border-style: solid;
`;

const TextInput = styled.input`
  font-family: Roboto;
  font-size: 13px;
  color: #FFFFFF;
  width: 72px;
  height: 15px;
  border: none;
  background: transparent;
`;

const SegmentTextWrapperRight = styled.div`
  flex: 1 1 0%;
  align-items: center;
  background-color: #FFFFFF;
  padding: 6px;
  border-width: 1px;
  border-color: #007AFF;
  border-bottom-right-radius: 5px;
  border-top-right-radius: 5px;
  flex-direction: column;
  display: flex;
  border-style: solid;
`;

const TextInput2 = styled.input`
  font-family: Roboto;
  font-size: 13px;
  color: rgba(0,0,0,1);
  width: 65px;
  height: 15px;
  background-color: rgba(15,15, 15,0);
  border: none;
  background: transparent;
`;

export default CupertinoSegmentWithTwoTabs;
