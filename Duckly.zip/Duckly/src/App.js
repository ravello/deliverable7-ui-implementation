import React from "react";
import { BrowserRouter as Router, Route } from "react-router-dom";
import "./icons.js";
import Collabscreen from "./screens/Collabscreen";
import Homescreen from "./screens/Homescreen";
import Homescreen1 from "./screens/Homescreen1";
import Homescreen2 from "./screens/Homescreen2";
import Homescreen3 from "./screens/Homescreen3";
import Homescreen4 from "./screens/Homescreen4";
import Login from "./screens/Login";
import Profile from "./screens/Profile";
import Signup from "./screens/Signup";
import StartSessionScreenSelectADirectory from "./screens/StartSessionScreenSelectADirectory";
import Untitled from "./screens/Untitled";
import Untitled1 from "./screens/Untitled1";
import Untitled2 from "./screens/Untitled2";
import Untitled3 from "./screens/Untitled3";
import "./style.css";

function App() {
  return (
    <Router>
      <Route path="/" exact component={Collabscreen} />
      <Route path="/Collabscreen/" exact component={Collabscreen} />
      <Route path="/Homescreen/" exact component={Homescreen} />
      <Route path="/Homescreen1/" exact component={Homescreen1} />
      <Route path="/Homescreen2/" exact component={Homescreen2} />
      <Route path="/Homescreen3/" exact component={Homescreen3} />
      <Route path="/Homescreen4/" exact component={Homescreen4} />
      <Route path="/Login/" exact component={Login} />
      <Route path="/Profile/" exact component={Profile} />
      <Route path="/Signup/" exact component={Signup} />
      <Route
        path="/StartSessionScreenSelectADirectory/"
        exact
        component={StartSessionScreenSelectADirectory}
      />
      <Route path="/Untitled/" exact component={Untitled} />
      <Route path="/Untitled1/" exact component={Untitled1} />
      <Route path="/Untitled2/" exact component={Untitled2} />
      <Route path="/Untitled3/" exact component={Untitled3} />
    </Router>
  );
}

export default App;
