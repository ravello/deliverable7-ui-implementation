import React, { Component } from "react";
import { StyleSheet, View, Text, TouchableOpacity } from "react-native";
import CupertinoButtonInfo from "../components/CupertinoButtonInfo";
import CupertinoButtonInfo1 from "../components/CupertinoButtonInfo1";
import CupertinoButtonInfo2 from "../components/CupertinoButtonInfo2";

function StartSessionScreenSelectADirectory(props) {
  return (
    <View style={styles.container}>
      <View style={styles.rect}>
        <Text style={styles.startSession}>Start Session</Text>
      </View>
      <View style={styles.cupertinoButtonInfoRowRow}>
        <View style={styles.cupertinoButtonInfoRow}>
          <CupertinoButtonInfo
            caption="Button"
            caption="Back"
            style={styles.cupertinoButtonInfo}
          ></CupertinoButtonInfo>
          <CupertinoButtonInfo1
            caption="Button"
            caption="Logout"
            style={styles.cupertinoButtonInfo1}
          ></CupertinoButtonInfo1>
        </View>
        <View style={styles.cupertinoButtonInfoRowFiller}>
          <Text style={styles.loremIpsum}>Choose a directory to work in</Text>
        </View>
      </View>
      <View style={styles.cupertinoButtonInfo2Stack}>
        <CupertinoButtonInfo2
          caption="Button"
          caption="Select Directory"
          style={styles.cupertinoButtonInfo2}
        ></CupertinoButtonInfo2>
        <TouchableOpacity
          onPress={() => props.navigation.navigate("StartSessionScreenDesktop")}
          style={styles.invisibleSelectDirectoryButton}
        ></TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  rect: {
    width: 1366,
    height: 42,
    backgroundColor: "#E6E6E6"
  },
  startSession: {
    fontFamily: "roboto-regular",
    color: "#121212",
    fontSize: 20,
    marginTop: 9,
    marginLeft: 26
  },
  cupertinoButtonInfo: {
    height: 44,
    width: 100
  },
  cupertinoButtonInfo1: {
    height: 44,
    width: 100,
    marginLeft: 1054
  },
  cupertinoButtonInfoRow: {
    height: 44,
    flexDirection: "row"
  },
  loremIpsum: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 41,
    width: 437,
    textAlign: "center",
    fontSize: 30,
    marginTop: 2
  },
  cupertinoButtonInfoRowFiller: {
    flex: 1,
    flexDirection: "row",
    justifyContent: "center"
  },
  cupertinoButtonInfoRowRow: {
    height: 44,
    flexDirection: "row",
    marginTop: 35,
    marginLeft: 56,
    marginRight: 56
  },
  cupertinoButtonInfo2: {
    height: 70,
    width: 208,
    position: "absolute",
    left: 0,
    top: 0
  },
  invisibleSelectDirectoryButton: {
    top: 0,
    left: 0,
    width: 208,
    height: 70,
    position: "absolute",
    backgroundColor: "#E6E6E6",
    opacity: 0
  },
  cupertinoButtonInfo2Stack: {
    width: 208,
    height: 70,
    marginTop: 228,
    marginLeft: 579
  }
});

export default StartSessionScreenSelectADirectory;
