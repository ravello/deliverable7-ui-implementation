import React, { Component } from "react";
import { StyleSheet, View, Text, TouchableOpacity } from "react-native";
import CupertinoButtonInfo from "../components/CupertinoButtonInfo";
import CupertinoButtonInfo1 from "../components/CupertinoButtonInfo1";
import EvilIconsIcon from "react-native-vector-icons/EvilIcons";

function StartSessionScreenProject1(props) {
  return (
    <View style={styles.container}>
      <View style={styles.rect1}>
        <Text style={styles.startSession1}>Start Session</Text>
      </View>
      <View style={styles.cupertinoButtonInfo1RowRow}>
        <View style={styles.cupertinoButtonInfo1Row}>
          <CupertinoButtonInfo
            caption="Button"
            caption="Back"
            style={styles.cupertinoButtonInfo1}
          ></CupertinoButtonInfo>
          <CupertinoButtonInfo1
            caption="Logout"
            style={styles.cupertinoButtonInfo2}
          ></CupertinoButtonInfo1>
        </View>
        <View style={styles.cupertinoButtonInfo1RowFiller}>
          <Text style={styles.loremIpsum1}>Choose a directory to work in</Text>
        </View>
      </View>
      <View style={styles.buttonColumnRow}>
        <View style={styles.buttonColumn}>
          <TouchableOpacity
            onPress={() =>
              props.navigation.navigate("StartSessionScreenDesktop")
            }
            style={styles.button}
          >
            <Text style={styles.desktop1}>Desktop</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() =>
              props.navigation.navigate("StartSessionScreenDocuments")
            }
            style={styles.button2}
          >
            <Text style={styles.documents}>Documents</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() =>
              props.navigation.navigate("StartSessionScreenDownloads")
            }
            style={styles.button3}
          >
            <Text style={styles.downloads}>Downloads</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.rect2}>
          <View style={styles.button4ColumnRow}>
            <View style={styles.button4Column}>
              <TouchableOpacity
                onPress={() =>
                  props.navigation.navigate("StartSessionScreenProject1")
                }
                style={styles.button4}
              >
                <Text style={styles.project12}>Project 1</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() =>
                  props.navigation.navigate("StartSessionScreenProject2")
                }
                style={styles.button5}
              >
                <Text style={styles.project2}>Project 2</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() =>
                  props.navigation.navigate("StartSessionScreenProject3")
                }
                style={styles.button6}
              >
                <Text style={styles.project3}>Project 3</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.rect3}>
              <View style={styles.iconStack}>
                <EvilIconsIcon
                  name="chevron-right"
                  style={styles.icon}
                ></EvilIconsIcon>
                <Text style={styles.loremIpsum3}>...</Text>
                <Text style={styles.desktop2}>Desktop</Text>
                <EvilIconsIcon
                  name="chevron-right"
                  style={styles.icon1}
                ></EvilIconsIcon>
                <Text style={styles.project1Files}>Project 1 Files</Text>
                <EvilIconsIcon
                  name="chevron-right"
                  style={styles.icon2}
                ></EvilIconsIcon>
              </View>
              <Text style={styles.license1}>This directory is empty...</Text>
            </View>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  rect1: {
    width: 1366,
    height: 42,
    backgroundColor: "#E6E6E6"
  },
  startSession1: {
    fontFamily: "roboto-regular",
    color: "#121212",
    fontSize: 20,
    marginTop: 9,
    marginLeft: 26
  },
  cupertinoButtonInfo1: {
    height: 44,
    width: 100
  },
  cupertinoButtonInfo2: {
    height: 44,
    width: 100,
    marginLeft: 1054
  },
  cupertinoButtonInfo1Row: {
    height: 44,
    flexDirection: "row"
  },
  loremIpsum1: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 41,
    width: 437,
    textAlign: "center",
    fontSize: 30,
    marginTop: 1
  },
  cupertinoButtonInfo1RowFiller: {
    flex: 1,
    flexDirection: "row",
    justifyContent: "center"
  },
  cupertinoButtonInfo1RowRow: {
    height: 44,
    flexDirection: "row",
    marginTop: 35,
    marginLeft: 56,
    marginRight: 56
  },
  button: {
    width: 105,
    height: 44,
    backgroundColor: "#E6E6E6",
    borderWidth: 1,
    borderColor: "#000000"
  },
  desktop1: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 19,
    width: 54,
    marginTop: 13,
    marginLeft: 26
  },
  button2: {
    width: 105,
    height: 44,
    backgroundColor: "#E6E6E6",
    marginTop: 7
  },
  documents: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 19,
    width: 72,
    marginTop: 13,
    marginLeft: 17
  },
  button3: {
    width: 105,
    height: 44,
    backgroundColor: "#E6E6E6",
    marginTop: 6
  },
  downloads: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 19,
    width: 70,
    marginTop: 13,
    marginLeft: 17
  },
  buttonColumn: {
    width: 105,
    marginTop: 47,
    marginBottom: 305
  },
  rect2: {
    width: 486,
    height: 497,
    backgroundColor: "#E6E6E6",
    borderWidth: 1,
    borderColor: "#000000"
  },
  button4: {
    width: 105,
    height: 44,
    backgroundColor: "rgba(192,192,192,1)",
    borderWidth: 1,
    borderColor: "#000000"
  },
  project12: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 19,
    width: 60,
    marginTop: 13,
    marginLeft: 26
  },
  button5: {
    width: 105,
    height: 44,
    backgroundColor: "rgba(192,192,192,1)",
    marginTop: 7
  },
  project2: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 19,
    width: 60,
    marginTop: 13,
    marginLeft: 26
  },
  button6: {
    width: 105,
    height: 44,
    backgroundColor: "rgba(192,192,192,1)",
    marginTop: 6
  },
  project3: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 19,
    width: 60,
    marginTop: 13,
    marginLeft: 26
  },
  button4Column: {
    width: 105,
    marginTop: 47,
    marginBottom: 305
  },
  rect3: {
    width: 323,
    height: 497,
    backgroundColor: "#E6E6E6",
    borderWidth: 1,
    borderColor: "#000000"
  },
  icon: {
    top: 0,
    left: 3,
    position: "absolute",
    color: "rgba(128,128,128,1)",
    fontSize: 40,
    height: 44,
    width: 40
  },
  loremIpsum3: {
    top: 14,
    left: 0,
    position: "absolute",
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 17,
    width: 13
  },
  desktop2: {
    top: 13,
    left: 38,
    position: "absolute",
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 19,
    width: 74
  },
  icon1: {
    top: 0,
    left: 81,
    position: "absolute",
    color: "rgba(128,128,128,1)",
    fontSize: 40,
    height: 44,
    width: 40
  },
  project1Files: {
    top: 13,
    left: 116,
    position: "absolute",
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 19,
    width: 98
  },
  icon2: {
    top: 0,
    left: 194,
    position: "absolute",
    color: "rgba(128,128,128,1)",
    fontSize: 40,
    height: 44,
    width: 40
  },
  iconStack: {
    width: 234,
    height: 44,
    marginLeft: 14
  },
  license1: {
    fontFamily: "roboto-regular",
    color: "rgba(117,117,117,1)",
    height: 20,
    width: 166,
    marginTop: 15,
    marginLeft: 27
  },
  button4ColumnRow: {
    height: 497,
    flexDirection: "row",
    marginLeft: 58
  },
  buttonColumnRow: {
    height: 497,
    flexDirection: "row",
    marginTop: 63,
    marginLeft: 335,
    marginRight: 440
  }
});

export default StartSessionScreenProject1;
